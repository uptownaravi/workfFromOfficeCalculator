import React, { useState } from 'react';
import { Calendar } from './components/Calendar';
import { Stats } from './components/Stats';
import { UserInput } from './components/UserInput';
import { Description } from './components/Description';
import { SubmitButton } from './components/SubmitButton';
import { startOfMonth } from 'date-fns';
import { Building2 } from 'lucide-react';
import { getWorkingDays } from './utils/dateUtils';
import { calculateAttendancePercentage } from './utils/calculationUtils';
import { saveAttendanceRecord } from './services/dynamodb';
import 'react-day-picker/dist/style.css';

export default function App() {
  const [username, setUsername] = useState('');
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [officeDays, setOfficeDays] = useState<Date[]>([]);
  const [holidays, setHolidays] = useState<Date[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSelectOfficeDay = (day: Date) => {
    const isSelected = officeDays.some(d => d.toDateString() === day.toDateString());
    if (isSelected) {
      setOfficeDays(officeDays.filter(d => d.toDateString() !== day.toDateString()));
    } else {
      setOfficeDays([...officeDays, day]);
    }
  };

  const handleSelectHoliday = (day: Date) => {
    const isSelected = holidays.some(d => d.toDateString() === day.toDateString());
    if (isSelected) {
      setHolidays(holidays.filter(d => d.toDateString() !== day.toDateString()));
    } else {
      setHolidays([...holidays, day]);
    }
  };

  const handleSubmit = async () => {
    if (!username.trim()) {
      alert('Please enter your username');
      return;
    }

    setIsSubmitting(true);
    const workingDays = getWorkingDays(month, holidays);
    const percentage = calculateAttendancePercentage(officeDays, workingDays);
    
    const data = {
      username,
      month,
      officeDays,
      holidays,
      attendancePercentage: percentage.toFixed(1) + '%'
    };

    try {
      const result = await saveAttendanceRecord(data);
      if (result.success) {
        alert('Attendance record saved successfully!');
      } else {
        throw new Error('Failed to save record');
      }
    } catch (error) {
      console.error('Error saving attendance record:', error);
      alert('Failed to save attendance record. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center space-x-2">
          <Building2 className="w-8 h-8 text-blue-500" />
          <h1 className="text-2xl font-bold">Office Days Tracker</h1>
        </div>

        <Description />

        <UserInput 
          username={username}
          onUsernameChange={setUsername}
        />

        <div className="grid md:grid-cols-2 gap-8">
          <Calendar
            month={month}
            officeDays={officeDays}
            holidays={holidays}
            onSelectOfficeDay={handleSelectOfficeDay}
            onSelectHoliday={handleSelectHoliday}
          />
          <Stats
            month={month}
            officeDays={officeDays}
            holidays={holidays}
          />
        </div>

        <div className="max-w-md mx-auto">
          <SubmitButton onSubmit={handleSubmit} isLoading={isSubmitting} />
        </div>
      </div>
    </div>
  );
}