import React, { useState } from 'react';
import { Calendar } from './components/Calendar';
import { Stats } from './components/Stats';
import { UserInput } from './components/UserInput';
import { Description } from './components/Description';
import { startOfMonth } from 'date-fns';
import { Building2 } from 'lucide-react';
import 'react-day-picker/dist/style.css'; // Add this import

export default function App() {
  const [username, setUsername] = useState('');
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [officeDays, setOfficeDays] = useState<Date[]>([]);
  const [holidays, setHolidays] = useState<Date[]>([]);

  const handleSelectOfficeDay = (day: Date) => {
    const isSelected = officeDays.some(d => d.toDateString() === day.toDateString());
    if (isSelected) {
      setOfficeDays(officeDays.filter(d => d.toDateString() !== day.toDateString()));
    } else {
      setOfficeDays([...officeDays, day]);
    }
  };

  const handleSelectHoliday = (day: Date) => {
    const isSelected = holidays.some(d => d.toDateString() === day.toDateString());
    if (isSelected) {
      setHolidays(holidays.filter(d => d.toDateString() !== day.toDateString()));
    } else {
      setHolidays([...holidays, day]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="flex items-center space-x-2">
          <Building2 className="w-8 h-8 text-blue-500" />
          <h1 className="text-2xl font-bold">Office Days Tracker</h1>
        </div>

        <Description />

        <UserInput 
          username={username}
          onUsernameChange={setUsername}
        />

        <div className="grid md:grid-cols-2 gap-8">
          <Calendar
            month={month}
            officeDays={officeDays}
            holidays={holidays}
            onSelectOfficeDay={handleSelectOfficeDay}
            onSelectHoliday={handleSelectHoliday}
          />
          <Stats
            month={month}
            officeDays={officeDays}
            holidays={holidays}
          />
        </div>
      </div>
    </div>
  );
}