import { format, isWeekend, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';

export const isSameDay = (date1: Date, date2: Date) => 
  format(date1, 'yyyy-MM-dd') === format(date2, 'yyyy-MM-dd');

export const getWorkingDays = (month: Date, holidays: Date[]) => 
  eachDayOfInterval({
    start: startOfMonth(month),
    end: endOfMonth(month),
  }).filter(date => !isWeekend(date) && !holidays.some(h => isSameDay(h, date)));

export const isDateInArray = (date: Date, dateArray: Date[]) =>
  dateArray.some(d => isSameDay(d, date));