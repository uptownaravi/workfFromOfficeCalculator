import { getWorkingDays } from './dateUtils';

export const calculateAttendancePercentage = (officeDays: Date[], workingDays: Date[]) => {
  return (officeDays.length / workingDays.length) * 100 || 0;
};