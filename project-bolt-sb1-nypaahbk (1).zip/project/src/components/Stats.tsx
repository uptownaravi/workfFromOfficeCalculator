import React, { useEffect, useState } from 'react';
import { getWorkingDays } from '../utils/dateUtils';
import { CheckCircle } from 'lucide-react';
import clsx from 'clsx';

interface StatsProps {
  month: Date;
  officeDays: Date[];
  holidays: Date[];
}

export function Stats({ month, officeDays, holidays }: StatsProps) {
  const workingDays = getWorkingDays(month, holidays);
  const percentage = (officeDays.length / workingDays.length) * 100 || 0;
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    setShowSuccess(percentage >= 60);
  }, [percentage]);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md space-y-4">
      <h2 className="text-xl font-semibold">Monthly Statistics</h2>
      <div className="space-y-2">
        <p>Total Working Days: {workingDays.length}</p>
        <p>Office Days: {officeDays.length}</p>
        <p>Holidays: {holidays.length}</p>
        <div className="relative">
          <p className="text-lg font-medium flex items-center gap-2">
            Office Attendance: {percentage.toFixed(1)}%
            <CheckCircle 
              className={clsx(
                "w-6 h-6 transition-all duration-500",
                showSuccess ? "text-green-500 scale-100 opacity-100" : "scale-0 opacity-0"
              )}
            />
          </p>
          <div className="mt-2 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div 
              className={clsx(
                "h-full transition-all duration-1000 ease-out",
                percentage >= 60 ? "bg-green-500" : "bg-blue-500"
              )}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}