import React from 'react';
import { Building2, Calendar, Info } from 'lucide-react';

export function Description() {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md space-y-4">
      <div className="flex items-center gap-2 text-gray-700">
        <Info className="w-5 h-5 text-blue-500" />
        <p className="text-lg">
          Calculate work from office percentage, don't need to remember when you came to office or guess the percentage. 
          Just update this app on weekly basis and complete the required work from office percentage.
        </p>
      </div>
      
      <div className="border-t pt-4">
        <h3 className="font-medium mb-2">How to use:</h3>
        <ul className="space-y-2 text-gray-600">
          <li className="flex items-center gap-2">
            <div className="w-4 h-4 bg-[#10B981] rounded"></div>
            Single click to select working from office day
          </li>
          <li className="flex items-center gap-2">
            <div className="w-4 h-4 bg-[#60A5FA] rounded"></div>
            Double click or two clicks to mark as holiday
          </li>
          <li className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Three clicks to revert selection
          </li>
        </ul>
      </div>
    </div>
  );
}