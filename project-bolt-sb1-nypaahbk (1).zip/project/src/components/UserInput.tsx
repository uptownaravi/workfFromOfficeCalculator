import React from 'react';
import { User } from 'lucide-react';

interface UserInputProps {
  username: string;
  onUsernameChange: (username: string) => void;
}

export function UserInput({ username, onUsernameChange }: UserInputProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center space-x-3">
        <User className="w-5 h-5 text-gray-500" />
        <input
          type="text"
          value={username}
          onChange={(e) => onUsernameChange(e.target.value)}
          placeholder="Enter your name"
          className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>
    </div>
  );
}