import React from 'react';
import { Save } from 'lucide-react';

interface SubmitButtonProps {
  onSubmit: () => void;
  isLoading?: boolean;
}

export function SubmitButton({ onSubmit, isLoading = false }: SubmitButtonProps) {
  return (
    <button
      onClick={onSubmit}
      disabled={isLoading}
      className="w-full px-4 py-3 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors disabled:bg-blue-300 flex items-center justify-center gap-2"
    >
      <Save className="w-5 h-5" />
      {isLoading ? 'Saving...' : 'Save Attendance Record'}
    </button>
  );
}