import React, { useState } from 'react';
import { DayPicker } from 'react-day-picker';
import { isWeekend } from 'date-fns';
import { isDateInArray } from '../utils/dateUtils';

interface CalendarProps {
  month: Date;
  officeDays: Date[];
  holidays: Date[];
  onSelectOfficeDay: (day: Date) => void;
  onSelectHoliday: (day: Date) => void;
}

export function Calendar({ month, officeDays, holidays, onSelectOfficeDay, onSelectHoliday }: CalendarProps) {
  const [clickCount, setClickCount] = useState<{ [key: string]: number }>({});

  const modifiers = {
    officeDays: officeDays,
    holidays: holidays,
    weekend: (date: Date) => isWeekend(date),
  };

  const modifiersStyles = {
    officeDays: { backgroundColor: '#10B981' },
    holidays: { backgroundColor: '#60A5FA' },
    weekend: { color: '#9CA3AF', cursor: 'not-allowed' }
  };

  const handleDayClick = (day: Date) => {
    if (isWeekend(day)) return;

    const dateKey = day.toISOString();
    const currentCount = (clickCount[dateKey] || 0) + 1;
    
    setClickCount(prev => ({
      ...prev,
      [dateKey]: currentCount > 3 ? 1 : currentCount
    }));

    const isOfficeDay = isDateInArray(day, officeDays);
    const isHoliday = isDateInArray(day, holidays);

    switch (currentCount) {
      case 1:
        // First click: Add as office day
        if (!isOfficeDay) onSelectOfficeDay(day);
        if (isHoliday) onSelectHoliday(day);
        break;
      case 2:
        // Second click: Change to holiday
        if (isOfficeDay) onSelectOfficeDay(day);
        if (!isHoliday) onSelectHoliday(day);
        break;
      case 3:
        // Third click: Clear all
        if (isHoliday) onSelectHoliday(day);
        if (isOfficeDay) onSelectOfficeDay(day);
        setClickCount(prev => ({ ...prev, [dateKey]: 0 }));
        break;
    }
  };

  return (
    <DayPicker
      mode="multiple"
      month={month}
      selected={[...officeDays, ...holidays]}
      onDayClick={handleDayClick}
      modifiers={modifiers}
      modifiersStyles={modifiersStyles}
      className="p-4 bg-white rounded-lg shadow-md"
    />
  );
}