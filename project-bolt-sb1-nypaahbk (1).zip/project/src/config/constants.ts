export const DB_CONFIG = {
  REGION: import.meta.env.VITE_AWS_REGION || 'us-east-1',
  TABLE_NAME: import.meta.env.VITE_DYNAMODB_TABLE || 'office-attendance-records'
};