import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand } from '@aws-sdk/lib-dynamodb';
import { DB_CONFIG } from '../config/constants';

const client = new DynamoDBClient({
  region: DB_CONFIG.REGION,
  credentials: {
    accessKeyId: import.meta.env.VITE_AWS_ACCESS_KEY_ID || '',
    secretAccessKey: import.meta.env.VITE_AWS_SECRET_ACCESS_KEY || ''
  }
});

const docClient = DynamoDBDocumentClient.from(client);

export const saveAttendanceRecord = async (data: {
  username: string;
  month: Date;
  officeDays: Date[];
  holidays: Date[];
  attendancePercentage: string;
}) => {
  const command = new PutCommand({
    TableName: DB_CONFIG.TABLE_NAME,
    Item: {
      userId: data.username,
      monthKey: data.month.toISOString().slice(0, 7), // YYYY-MM format
      ...data,
      createdAt: new Date().toISOString(),
      officeDays: data.officeDays.map(d => d.toISOString()),
      holidays: data.holidays.map(d => d.toISOString())
    }
  });

  try {
    await docClient.send(command);
    return { success: true };
  } catch (error) {
    console.error('Error saving to DynamoDB:', error);
    return { success: false, error };
  }
};