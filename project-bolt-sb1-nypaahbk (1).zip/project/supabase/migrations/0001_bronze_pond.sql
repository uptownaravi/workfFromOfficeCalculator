/*
  # Work Records Schema

  1. New Tables
    - `work_records`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `month` (date, stores the first day of the month)
      - `office_days` (date[], stores days working from office)
      - `holidays` (date[], stores holiday dates)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on work_records table
    - Add policies for CRUD operations
*/

CREATE TABLE IF NOT EXISTS work_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  month date NOT NULL,
  office_days date[] DEFAULT '{}',
  holidays date[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, month)
);

ALTER TABLE work_records ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Users can view their own records"
  ON work_records
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own records"
  ON work_records
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own records"
  ON work_records
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);